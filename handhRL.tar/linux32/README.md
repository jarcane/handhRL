This folder contains *.so library files for 32-bit Linux x86.
